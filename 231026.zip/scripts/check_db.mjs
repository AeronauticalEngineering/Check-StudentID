import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs } from "firebase/firestore";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function check() {
  console.log("Checking Firestore...");
  const catSnap = await getDocs(collection(db, "categories"));
  console.log("Categories count:", catSnap.size);
  catSnap.forEach(d => console.log("Category:", d.id, JSON.stringify(d.data())));

  const actSnap = await getDocs(collection(db, "activities"));
  console.log("Activities count:", actSnap.size);
  actSnap.forEach(d => console.log("Activity:", d.id, d.data().name, "Type:", d.data().type));
}

check().catch(console.error);
