import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function POST(request) {
  try {
    const body = await request.json();
    const base64 = body.base64 || body.file;
    const targetPath = body.path || (body.folder ? `${body.folder}/cert_${Date.now()}.png` : null);

    if (!base64) {
      return NextResponse.json({ error: 'No image data provided' }, { status: 400 });
    }

    // Extract base64 content
    const matches = base64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return NextResponse.json({ error: 'Invalid base64 string' }, { status: 400 });
    }

    const buffer = Buffer.from(matches[2], 'base64');

    // Try writing to local filesystem (works in local development)
    try {
      const cleanFilename = (targetPath || `evidence_${Date.now()}.jpg`)
        .replace(/^documents\//, '')
        .replace(/\//g, '_')
        .replace(/[^a-zA-Z0-9._-]/g, '_');

      const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      const filePath = path.join(uploadsDir, cleanFilename);
      await fs.promises.writeFile(filePath, buffer);

      const publicUrl = `/uploads/${cleanFilename}`;
      return NextResponse.json({ url: publicUrl, success: true });
    } catch (fsError) {
      // In serverless environments like Vercel / AWS Lambda, the local filesystem is read-only.
      // Gracefully fall back to returning the base64 data URL directly, which works everywhere for images and canvas!
      console.warn('Filesystem write not available (serverless/Vercel): falling back to direct base64 data URL.');
      return NextResponse.json({ url: base64, success: true });
    }
  } catch (error) {
    console.error('Upload API error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
